# Blank Slate
MAIN OBJECTIVE: Completed
  Art interface (user can select different colors and pen sizes), 
  User will be able to draw in a space provided in the interface, 
  They can save the drawing to their computer, 
  
FEATURES TBA (To Be Added): Pending
  Later put in a file retrieval system and allow them to re-edit a previously made drawing,  
  Can add actual shapes such as rectangles or ovals to the drawing,
  Undo button for mistakes, 
  Eraser option that uses brush size tool as well, 
  Bucket option to fill an area with a color, 
  Gradient option. 
